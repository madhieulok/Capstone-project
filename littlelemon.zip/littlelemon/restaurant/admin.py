from django.contrib import admin
#from restaurant .models import MenuItem, Category


# Register your models here.
#admin.site.register(MenuItem)
#admin.site.register(Category)
